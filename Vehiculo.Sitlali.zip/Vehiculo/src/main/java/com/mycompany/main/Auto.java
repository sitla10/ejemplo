/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author Admin
 */
public class Auto {

    Vehiculo vehiculo1=new Vehiculo();
    vehiculo1.
    }
    
}
